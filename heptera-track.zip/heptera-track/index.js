var express = require('express');
var app = express();
const bodyParser = require("body-parser");
var getIP = require('ipware')().get_ip;

var http = require("http");


app.get("/social/:url_id/:tp", (req, res) => {

jsn_arr={};

var ipInfo = getIP(req);

ipInfo="23.235.60.92";


jsn_arr.ip=ipInfo;
jsn_arr.url=req.params.url_id;
jsn_arr.tp=req.params.tp;


isrt_soc_ana_camp(jsn_arr,function(res){


console.log(res);


});

console.log(req.params.url_id);

req_for_redirect={};

req_for_redirect.match_fld="camp_id";
req_for_redirect.get_fld="url";
req_for_redirect.url_id=req.params.url_id;
req_for_redirect.tbl_name="post_data_url";

url_red_fld(req_for_redirect,function(res2){


res.redirect(res2);


})

});
app.listen(3000, () => {
  console.log("Server is running on port 3000.");
});







app.get("/email/open/:con_id/:lst_name/:camp_name", (req, res) => {


req_data={};


req_data.tbl_name=req.params.lst_name;
req_data.con_id=req.params.con_id;
req_data.update_fld=req.params.camp_name;
req_data.update_tag=2;


update_fld_of_db(req_data,function(res2){


console.log(res2);






});

req_of_isrt_data={};


var ipInfo = getIP(req);

ipInfo="157.32.243.243";



req_of_isrt_data.con_id=req.params.con_id;
req_of_isrt_data.act_flg=2;
req_of_isrt_data.ip=ipInfo;


req_of_isrt_data.tbl_name=req.params.camp_name+"#"+req.params.lst_name;


isrt_in_ana_db(req_of_isrt_data,function(){


console.log("insert successfull");

})

});









app.get("/email/click/:con_id/:lst_name/:camp_name/:flg_data", (req, res) => {


req_data={};


req_data.tbl_name=req.params.lst_name;
req_data.con_id=req.params.con_id;
req_data.update_fld=req.params.camp_name;
req_data.update_tag=req.params.flg_data;


update_fld_of_db(req_data,function(res2){


console.log(res2);






});

req_of_isrt_data={};


var ipInfo = getIP(req);

ipInfo="157.32.243.243";



req_of_isrt_data.con_id=req.params.con_id;
req_of_isrt_data.act_flg=req.params.flg_data;
req_of_isrt_data.ip=ipInfo;

req_of_isrt_data.tbl_name=req.params.camp_name+"#"+req.params.lst_name;


isrt_in_ana_db(req_of_isrt_data,function(){


console.log("insert successfull");

})





req_for_redirect={};

req_for_redirect.match_fld="url_id";
req_for_redirect.get_fld="url";
req_for_redirect.url_id=req.params.camp_name+"@"+req.params.flg_data;
req_for_redirect.tbl_name="temp_url_data_crw";

url_red_fld(req_for_redirect,function(res2){


res.redirect(res2);


})

});














function isrt_in_ana_db(req_data,callback){


id=req_data.con_id;
act=req_data.act_flg;
ip_data=req_data.ip;
tbl_name=req_data.tbl_name;





const axios = require('axios');


axios.post("http://www.geoplugin.net/json.gp",{
  params: {
    ip:ip_data
  }
}).then(response => {

cnt=response.data.geoplugin_countryCode;
reg=response.data.geoplugin_regionCode;

var dt_tm = new Date().toISOString("en-US", {timeZone: "America/Los_Angeles"});



console.log(dt_tm);


const social_conn = require("./confige/email_analysis.confige.js");



social_conn.query('INSERT INTO `'+tbl_name+'` (id,act,cnt,act_date,reg) values ("'+id+'","'+act+'","'+cnt+'","'+dt_tm+'","'+reg+'")', (err, results) => {
    

       if (err) {
      console.log("error: ", err);
      
    }else{


      console.log("insert successfull");
    }



   
      
    
});



}).catch(error => {
    console.log(error);
  });





}












function update_fld_of_db(req_data,callback){


tbl_name=req_data.tbl_name;
update_fld=req_data.update_fld;
update_tag=req_data.update_tag;
usr_id=req_data.con_id;



const contact_conn = require("./confige/contact.confige.js");




contact_conn.query('update `'+tbl_name+'` set `'+update_fld+'`="'+update_tag+'" where con_id="'+usr_id+'"', (err, results) => {
    

       if (err) {
      console.log("error: ", err);
      
    }else{


      console.log("update successfull");
    }



   
      
    
});


callback(0);

}








function isrt_soc_ana_camp(req_data,callback){



const social_conn = require("./confige/social_post_analysis.confige.js");


tbl_name=req_data.url;

console.log(req_data.ip);


const axios = require('axios');


axios.post("http://www.geoplugin.net/json.gp",{
  params: {
    ip:req_data.ip
  }
}).then(response => {



lat_of_usr=response.data.geoplugin_latitude;
lag_of_usr=response.data.geoplugin_longitude;

req_data.ip=response.data.geoplugin_countryCode;

var dt_tm = new Date().toISOString("en-US", {timeZone: "America/Los_Angeles"});




social_conn.query('INSERT INTO `'+req_data.url+'` (tp_acc,ip_dt,lat,lag,acc_date) values ("'+req_data.tp+'","'+req_data.ip+'","'+lat_of_usr+'","'+lag_of_usr+'","'+dt_tm+'")', (err, results) => {
    

       if (err) {
      console.log("error: ", err);
      
    }else{


      console.log("insert successfull");
    }



   
      
    
});



}).catch(error => {
    console.log(error);
  });





callback(req_data);



}





function url_red_fld(req_data,callback){



url_id=req_data.url_id;
match_fld=req_data.match_fld;
ret_fld=req_data.get_fld;
tbl_name=req_data.tbl_name;


 social_conn = require("./confige/camp_url_data.confige.js");

if(tbl_name=="post_data_url"){

console.log("ravi");

 social_conn = require("./confige/social_post.confige.js");
}

sel_query='SELECT * FROM `'+tbl_name+'` WHERE `'+match_fld+'`="'+url_id+'"';
console.log(sel_query);

social_conn.query(sel_query, (err, results) => {
    

console.log(results);

    var resultArray = Object.values(JSON.parse(JSON.stringify(results)))

       
      

       callback(resultArray[0].url);


   
    
});





}



